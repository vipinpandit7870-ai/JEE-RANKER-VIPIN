-- JEE RANKER VIPIN: Supabase schema
-- Run this whole file in Supabase Dashboard > SQL Editor > New query.
-- IMPORTANT: never expose the service_role key in the browser.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  role text not null default 'student' check (role in ('student','admin')),
  created_at timestamptz not null default now()
);

create table if not exists public.questions (
  id uuid primary key default gen_random_uuid(),
  subject text not null check (subject in ('Physics','Chemistry','Mathematics')),
  topic text not null,
  question_en text not null,
  question_hi text not null default '',
  options jsonb not null check (jsonb_typeof(options) = 'array' and jsonb_array_length(options) = 4),
  answer_index integer not null check (answer_index between 0 and 3),
  explanation text not null default '',
  is_published boolean not null default false,
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now()
);

create table if not exists public.attempts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  question_id text not null,
  selected_option integer not null check (selected_option between 0 and 3),
  is_correct boolean not null,
  created_at timestamptz not null default now()
);

create table if not exists public.user_bookmarks (
  user_id uuid primary key references auth.users(id) on delete cascade,
  question_ids jsonb not null default '[]'::jsonb,
  updated_at timestamptz not null default now()
);

create table if not exists public.study_progress (
  user_id uuid primary key references auth.users(id) on delete cascade,
  completed_topics jsonb not null default '[]'::jsonb,
  updated_at timestamptz not null default now()
);

-- Create a student profile automatically after email signup.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, display_name, role)
  values (new.id, coalesce(new.raw_user_meta_data->>'display_name', split_part(new.email,'@',1)), 'student')
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

-- SECURITY DEFINER avoids recursive profiles RLS when checking the role.
create or replace function public.is_jee_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.profiles p
    where p.id = auth.uid() and p.role = 'admin'
  );
$$;

alter table public.profiles enable row level security;
alter table public.questions enable row level security;
alter table public.attempts enable row level security;
alter table public.user_bookmarks enable row level security;
alter table public.study_progress enable row level security;

drop policy if exists "profile read own" on public.profiles;
create policy "profile read own" on public.profiles
for select to authenticated using (id = auth.uid() or public.is_jee_admin());
-- No client UPDATE/INSERT policy for profiles. This prevents users promoting themselves to admin.
-- Admin role should be assigned only from the Supabase SQL Editor by the project owner.

drop policy if exists "published questions readable" on public.questions;
create policy "published questions readable" on public.questions
for select to anon, authenticated
using (is_published = true or public.is_jee_admin());

drop policy if exists "admins insert questions" on public.questions;
create policy "admins insert questions" on public.questions
for insert to authenticated
with check (public.is_jee_admin() and created_by = auth.uid());

drop policy if exists "admins update questions" on public.questions;
create policy "admins update questions" on public.questions
for update to authenticated
using (public.is_jee_admin()) with check (public.is_jee_admin());

drop policy if exists "admins delete questions" on public.questions;
create policy "admins delete questions" on public.questions
for delete to authenticated using (public.is_jee_admin());

drop policy if exists "attempts insert own" on public.attempts;
create policy "attempts insert own" on public.attempts
for insert to authenticated with check (user_id = auth.uid());

drop policy if exists "attempts read own or admin" on public.attempts;
create policy "attempts read own or admin" on public.attempts
for select to authenticated using (user_id = auth.uid() or public.is_jee_admin());

drop policy if exists "bookmarks own read" on public.user_bookmarks;
create policy "bookmarks own read" on public.user_bookmarks
for select to authenticated using (user_id = auth.uid() or public.is_jee_admin());
drop policy if exists "bookmarks own insert" on public.user_bookmarks;
create policy "bookmarks own insert" on public.user_bookmarks
for insert to authenticated with check (user_id = auth.uid());
drop policy if exists "bookmarks own update" on public.user_bookmarks;
create policy "bookmarks own update" on public.user_bookmarks
for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
drop policy if exists "bookmarks own delete" on public.user_bookmarks;
create policy "bookmarks own delete" on public.user_bookmarks
for delete to authenticated using (user_id = auth.uid());

drop policy if exists "progress own read" on public.study_progress;
create policy "progress own read" on public.study_progress
for select to authenticated using (user_id = auth.uid() or public.is_jee_admin());
drop policy if exists "progress own insert" on public.study_progress;
create policy "progress own insert" on public.study_progress
for insert to authenticated with check (user_id = auth.uid());
drop policy if exists "progress own update" on public.study_progress;
create policy "progress own update" on public.study_progress
for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
drop policy if exists "progress own delete" on public.study_progress;
create policy "progress own delete" on public.study_progress
for delete to authenticated using (user_id = auth.uid());

-- Add an admin after that person has signed up. Replace the email with your own.
-- Run separately in SQL Editor only after signup:
-- update public.profiles
-- set role = 'admin'
-- where id = (select id from auth.users where email = 'YOUR_EMAIL@example.com');
--
-- Add a published question from SQL Editor (example):
-- insert into public.questions
-- (subject, topic, question_en, question_hi, options, answer_index, explanation, is_published)
-- values ('Physics','Kinematics','A sample question?','एक नमूना प्रश्न?',
-- '["A","B","C","D"]'::jsonb, 0, 'Demo explanation', true);
