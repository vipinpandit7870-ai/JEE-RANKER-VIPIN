JEE RANKER VIPIN — Full Portal Starter (free-to-start)

CONTENTS
- index.html: responsive front-end, bilingual sample practice, local planner, mock test, login/signup UI, cloud sync hooks, role-gated admin form
- supabase_schema.sql: database tables, row-level security (RLS), profile trigger and admin policies
- README.txt: setup and deployment guide

IMPORTANT HONEST STATUS
This package is a working front-end starter. Login, cloud sync, and admin saving are intentionally disabled until you create your own Supabase project and configure its URL/public key. Do not expect a deployed website to have working accounts until these setup steps are completed.

FREE-TO-START SERVICES
1. GitHub account: stores the code and can host the static website with GitHub Pages.
2. Supabase account: provides the Postgres database and email/password authentication on its free tier (limits and plan terms can change).
3. A web browser. A custom domain is optional and usually costs money.

SETUP: SUPABASE
1. Create a project at https://supabase.com/ and save the database password somewhere secure.
2. Open SQL Editor > New query; paste/run all of supabase_schema.sql.
3. Open Project Settings > API (or the current API keys page). Copy the Project URL and the public anon/publishable key.
4. Open index.html and replace:
   SUPABASE_URL = "PASTE_YOUR_SUPABASE_PROJECT_URL_HERE";
   SUPABASE_ANON_KEY = "PASTE_YOUR_SUPABASE_PUBLIC_ANON_KEY_HERE";
   with your own project URL and public browser key.
5. Never use a service_role or secret key in index.html. The browser key is public by design; RLS is what protects data.
6. In Supabase Authentication settings, configure the allowed site URL and redirect URLs for your GitHub Pages URL, e.g. https://YOUR-USERNAME.github.io/YOUR-REPOSITORY/ . Also configure email confirmation according to your preference. For password reset links, set the redirect URL to your published website.
7. Create an account using the website. If email confirmation is on, confirm the email first.
8. Make that account an admin: Supabase SQL Editor > run the following query after replacing the email:
   update public.profiles
   set role = 'admin'
   where id = (select id from auth.users where email = 'YOUR_EMAIL@example.com');
   Do not add an admin self-service form. Only the project owner should assign roles from the SQL Editor.
9. Sign in again. Admin panel should display the protected question creation form.
10. Questions created in the admin panel are not automatically published; set is_published = true for questions you have reviewed. The current front-end demo question list remains the built-in sample bank; database-backed question browsing is a follow-up implementation step. Admin form writes questions to the database.

DEPLOY TO GITHUB PAGES
1. Create a GitHub repository, e.g. jee-ranker-vipin.
2. Upload index.html to the repository root. You may also upload this README and SQL file.
3. Repository > Settings > Pages > Build and deployment: Deploy from a branch; choose main and /(root), then Save.
4. Wait for the deployment to finish and open the Pages URL shown there.
5. Add that exact URL under Supabase Authentication's allowed site/redirect URLs.
6. If you edit index.html later, commit/push the change; GitHub Pages redeploys automatically.

SECURITY NOTES
- The SQL enables RLS on all user data tables.
- Users can read their own profile and cannot update their role from the client.
- Users can read/write only their own progress/bookmarks and read their own attempts.
- Only admins can insert/update/delete questions; public users can read published questions.
- Never expose the service_role key. Do not turn off RLS to make a demo “work”.
- This is a starter security model, not a substitute for a security review before real users or sensitive information.
- Do not collect unnecessary personal information. If children use the site, review applicable privacy and consent requirements.

CURRENT LIMITATIONS
- Built-in practice and mock questions are small original demo content, not a full verified JEE PYQ library.
- Front-end mock-test scoring is a demo and is not an official rank predictor.
- Account auth and cloud sync work only after Supabase configuration and SQL setup.
- The admin form saves question rows to Supabase, but loading/publishing the database question bank into the student practice view still needs to be wired in a future step.
- GitHub Pages is static hosting; it does not run server-side code. Supabase is the separate backend.
- GitHub Pages and Supabase have free-tier limits/terms that may change; no service can be guaranteed free forever.
- This project is independent and not affiliated with ExamGOAL, NTA or IITs.
